<!-- !============= Header Area Start ===========!
 -->
 <header class="rt-site-header rt-sticky home-two white-menu bsnav">
        <nav class="navbar navbar-expand-lg rt-one-page-menu">
            <div class="container">
        
                <a href="#home" class="brand-logo smooth-scroll"><img src="assets/images/logo/intap-logo-white.png" alt=""></a>
                <a href="#home" class="sticky-logo smooth-scroll"><img src="assets/images/logo/intap-logo-white.png" alt=""></a>
        
                <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#siteNav"
                    aria-controls="siteNav" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                    <span class="navbar-toggler-icon"></span>
                    <span class="navbar-toggler-icon"></span>
                </button>
        
                <div class="collapse navbar-collapse" id="siteNav">
                    <ul class="navbar-nav ml-auto">
                        
                        <!--COMMENTED THE DROPDOWN MENU HERE                         
                        <li class="nav-item active dropdown"><a href="index-3.htm" role="button"
                                class="nav-link smooth-scroll dropdown-toggle" id="dropdownMenuLink" data-toggle="dropdown"
                                aria-haspopup="true" aria-expanded="false">home</a>
                            <div class="dropdown-menu" aria-labelledby="dropdownMenuLink">
                            
                                <a href="#home" class="nav-link smooth-scroll">home 3</a>
                              
                            </div>
                        </li> -->
                        <li class="nav-item"><a href="#home" class="nav-link smooth-scroll">Home</a></li>
                        <li class="nav-item"><a href="#feature" class="nav-link smooth-scroll">Skills</a></li>
                        <li class="nav-item"><a href="#overview" class="nav-link smooth-scroll">Services</a></li>
                        <li class="nav-item"><a href="#price" class="nav-link smooth-scroll">Pricing</a></li>
                        <li class="nav-item"><a href="#fAQ" class="nav-link smooth-scroll">FAQ</a></li>
                    </ul>
                    <div class="rt-menu-tolls">
                        <a href="#download" class="rt-btn rt-gradient pill text-uppercase smooth-scroll">Schedule a call</a>
                    </div>
                </div>
        
            </div>
        </nav>
    </header>